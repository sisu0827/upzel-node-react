import React from 'react'

export default () => {
  return (
    <div className="top-border">
      <span className="top-border__sec-blue"></span>
      <span className="top-border__pri-blue"></span>
      <span className="top-border__green"></span>
      <span className="top-border__orange"></span>
      <span className="top-border__red"></span>
    </div>
  )
}
